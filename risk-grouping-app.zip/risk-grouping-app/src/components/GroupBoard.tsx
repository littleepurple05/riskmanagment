import type { Bucket, RiskRow } from '../types'

type Props = {
  rows: RiskRow[]
  columns: string[]
  buckets: Bucket[]
  draggedRowId: string | null
  onDragStart: (rowId: string) => void
  onDropRow: (bucketName: string, subBucketName: string) => void
}

export function GroupBoard({ rows, columns, buckets, onDragStart, onDropRow }: Props) {
  const ungroupedRows = rows.filter((row) => !row.group)

  return (
    <div className="board-layout">
      <section className="panel sticky-panel">
        <h2>未分類の行</h2>
        <p className="panel-note">行をドラッグして、右側の箱へ入れてください。</p>
        <div className="card-list">
          {ungroupedRows.length === 0 && <div className="empty-box">未分類の行はありません。</div>}
          {ungroupedRows.map((row) => (
            <div
              key={row.id}
              className="risk-card"
              draggable
              onDragStart={() => onDragStart(row.id)}
            >
              <div className="risk-card-title">行 {row.rowNo}</div>
              {columns.slice(0, 3).map((column) => (
                <div key={column} className="risk-card-text">
                  <strong>{column}</strong>: {row.values[column] ?? ''}
                </div>
              ))}
            </div>
          ))}
        </div>
      </section>

      <section className="bucket-grid">
        {buckets.map((bucket) => {
          const bucketRows = rows.filter((row) => row.group === bucket.name)
          return (
            <div
              key={bucket.id}
              className="panel bucket-panel"
              onDragOver={(event) => event.preventDefault()}
              onDrop={() => onDropRow(bucket.name, '未分類')}
            >
              <div className="bucket-header">
                <h2>{bucket.name}</h2>
                <span className="count-badge">{bucketRows.length}</span>
              </div>

              {bucket.subBuckets.map((subBucket) => {
                const subRows = bucketRows.filter(
                  (row) => (row.subGroup || '未分類') === subBucket,
                )
                return (
                  <div
                    key={`${bucket.id}-${subBucket}`}
                    className="sub-bucket"
                    onDragOver={(event) => event.preventDefault()}
                    onDrop={() => onDropRow(bucket.name, subBucket)}
                  >
                    <div className="bucket-header compact">
                      <h3>{subBucket}</h3>
                      <span className="count-badge">{subRows.length}</span>
                    </div>

                    {subRows.length === 0 ? (
                      <div className="drop-hint">ここにドロップ</div>
                    ) : (
                      <div className="mini-card-list">
                        {subRows.map((row) => (
                          <div
                            key={row.id}
                            className="mini-card"
                            draggable
                            onDragStart={() => onDragStart(row.id)}
                          >
                            <div className="risk-card-title">行 {row.rowNo}</div>
                            <div className="risk-card-text">
                              {columns
                                .slice(0, 2)
                                .map((column) => `${column}: ${row.values[column] ?? ''}`)
                                .join(' / ')}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          )
        })}
      </section>
    </div>
  )
}
