import type { ChangeEvent } from 'react'

type Props = {
  search: string
  onSearchChange: (value: string) => void
  onFileChange: (event: ChangeEvent<HTMLInputElement>) => void
  onExport: () => void
  onAddBucket: () => void
  disabledExport: boolean
}

export function Toolbar({
  search,
  onSearchChange,
  onFileChange,
  onExport,
  onAddBucket,
  disabledExport,
}: Props) {
  return (
    <div className="toolbar">
      <div className="toolbar-left">
        <label className="button primary">
          Excelを読み込む
          <input type="file" accept=".xlsx,.xls,.csv" hidden onChange={onFileChange} />
        </label>
        <button className="button" onClick={onExport} disabled={disabledExport}>
          Excelを書き出す
        </button>
        <button className="button" onClick={onAddBucket}>
          大箱子を追加
        </button>
      </div>
      <input
        className="search"
        placeholder="キーワード検索"
        value={search}
        onChange={(event) => onSearchChange(event.target.value)}
      />
    </div>
  )
}
