import type { Bucket, RiskRow } from '../types'

type Props = {
  rows: RiskRow[]
  columns: string[]
  buckets: Bucket[]
  onUpdateCell: (rowId: string, column: string, value: string) => void
  onUpdateGroup: (rowId: string, group: string) => void
  onUpdateSubGroup: (rowId: string, subGroup: string) => void
}

export function DataTable({
  rows,
  columns,
  buckets,
  onUpdateCell,
  onUpdateGroup,
  onUpdateSubGroup,
}: Props) {
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>行</th>
            <th>大分類</th>
            <th>小分類</th>
            {columns.map((column) => (
              <th key={column}>{column}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => {
            const subBuckets = buckets.find((bucket) => bucket.name === row.group)?.subBuckets ?? ['未分類']
            return (
              <tr key={row.id}>
                <td>{row.rowNo}</td>
                <td>
                  <select value={row.group} onChange={(event) => onUpdateGroup(row.id, event.target.value)}>
                    <option value="">未分類</option>
                    {buckets.map((bucket) => (
                      <option key={bucket.id} value={bucket.name}>
                        {bucket.name}
                      </option>
                    ))}
                  </select>
                </td>
                <td>
                  <select
                    value={row.subGroup || '未分類'}
                    onChange={(event) => onUpdateSubGroup(row.id, event.target.value)}
                  >
                    {subBuckets.map((subBucket) => (
                      <option key={subBucket} value={subBucket}>
                        {subBucket}
                      </option>
                    ))}
                  </select>
                </td>
                {columns.map((column) => (
                  <td key={column}>
                    <input
                      value={row.values[column] ?? ''}
                      onChange={(event) => onUpdateCell(row.id, column, event.target.value)}
                    />
                  </td>
                ))}
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}
