import type { Bucket } from '../types'

type Props = {
  buckets: Bucket[]
  onRenameBucket: (bucketId: string, name: string) => void
  onRemoveBucket: (bucketId: string) => void
  onAddSubBucket: (bucketId: string) => void
  onRenameSubBucket: (bucketId: string, oldName: string, newName: string) => void
  onRemoveSubBucket: (bucketId: string, subBucketName: string) => void
}

export function CategoryManager({
  buckets,
  onRenameBucket,
  onRemoveBucket,
  onAddSubBucket,
  onRenameSubBucket,
  onRemoveSubBucket,
}: Props) {
  return (
    <div className="manager-grid">
      {buckets.map((bucket) => (
        <section key={bucket.id} className="panel">
          <div className="manager-header">
            <input value={bucket.name} onChange={(event) => onRenameBucket(bucket.id, event.target.value)} />
            <button className="danger-button" onClick={() => onRemoveBucket(bucket.id)}>
              削除
            </button>
          </div>

          <div className="subbucket-list">
            {bucket.subBuckets.map((subBucket) => (
              <div key={`${bucket.id}-${subBucket}`} className="subbucket-item">
                <input
                  value={subBucket}
                  onChange={(event) => onRenameSubBucket(bucket.id, subBucket, event.target.value)}
                />
                {subBucket !== '未分類' && (
                  <button className="danger-button" onClick={() => onRemoveSubBucket(bucket.id, subBucket)}>
                    削除
                  </button>
                )}
              </div>
            ))}
          </div>

          <button className="button" onClick={() => onAddSubBucket(bucket.id)}>
            小箱子を追加
          </button>
        </section>
      ))}
    </div>
  )
}
