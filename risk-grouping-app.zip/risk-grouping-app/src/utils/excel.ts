import * as XLSX from 'xlsx'
import type { Bucket, RiskRow } from '../types'

export const DEFAULT_BUCKET_NAMES = [
  'グローバル市場（日本を含めて）での競争優位',
  '（外部）法規制・政治リスク',
  '人財育成',
  '新技術・製品開発',
  '自然・災害',
  '業務効率化',
  '組織文化・コンプライアンス',
  'その他',
]

export function createDefaultBuckets(): Bucket[] {
  return DEFAULT_BUCKET_NAMES.map((name) => ({
    id: crypto.randomUUID(),
    name,
    subBuckets: ['未分類'],
  }))
}

export async function parseExcel(file: File): Promise<{ rows: RiskRow[]; columns: string[] }> {
  const buffer = await file.arrayBuffer()
  const workbook = XLSX.read(buffer)
  const firstSheet = workbook.Sheets[workbook.SheetNames[0]]
  const json = XLSX.utils.sheet_to_json<Record<string, unknown>>(firstSheet, { defval: '' })

  const rows: RiskRow[] = json.map((entry, index) => {
    const record: Record<string, string> = {}
    for (const [key, value] of Object.entries(entry)) {
      if (!key || key === '大分類' || key === '小分類' || key === '行番号') continue
      record[key] = String(value ?? '')
    }

    return {
      id: crypto.randomUUID(),
      rowNo: index + 1,
      group: String(entry['大分類'] ?? ''),
      subGroup: String(entry['小分類'] ?? ''),
      values: record,
    }
  })

  const columnSet = new Set<string>()
  rows.forEach((row) => Object.keys(row.values).forEach((key) => columnSet.add(key)))

  return {
    rows,
    columns: Array.from(columnSet),
  }
}

export function exportExcel(rows: RiskRow[], columns: string[]) {
  const exportRows = rows.map((row) => {
    const payload: Record<string, string | number> = {
      行番号: row.rowNo,
      大分類: row.group,
      小分類: row.subGroup,
    }

    columns.forEach((column) => {
      payload[column] = row.values[column] ?? ''
    })

    return payload
  })

  const workbook = XLSX.utils.book_new()
  const worksheet = XLSX.utils.json_to_sheet(exportRows)
  XLSX.utils.book_append_sheet(workbook, worksheet, 'RiskGrouping')
  XLSX.writeFile(workbook, 'risk_grouping_result.xlsx')
}
