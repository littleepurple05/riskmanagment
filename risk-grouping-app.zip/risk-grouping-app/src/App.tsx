import { useMemo, useState, type ChangeEvent } from 'react'
import { CategoryManager } from './components/CategoryManager'
import { DataTable } from './components/DataTable'
import { GroupBoard } from './components/GroupBoard'
import { Toolbar } from './components/Toolbar'
import type { Bucket, RiskRow } from './types'
import { createDefaultBuckets, exportExcel, parseExcel } from './utils/excel'

type ViewMode = 'board' | 'table' | 'manage'

function App() {
  const [rows, setRows] = useState<RiskRow[]>([])
  const [columns, setColumns] = useState<string[]>([])
  const [buckets, setBuckets] = useState<Bucket[]>(createDefaultBuckets)
  const [viewMode, setViewMode] = useState<ViewMode>('board')
  const [search, setSearch] = useState('')
  const [draggedRowId, setDraggedRowId] = useState<string | null>(null)

  const filteredRows = useMemo(() => {
    if (!search.trim()) return rows
    const keyword = search.toLowerCase()
    return rows.filter((row) => {
      const combined = [
        row.group,
        row.subGroup,
        String(row.rowNo),
        ...Object.values(row.values),
      ]
        .join(' ')
        .toLowerCase()
      return combined.includes(keyword)
    })
  }, [rows, search])

  const handleFileChange = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return
    const parsed = await parseExcel(file)
    setRows(parsed.rows)
    setColumns(parsed.columns)
  }

  const handleUpdateCell = (rowId: string, column: string, value: string) => {
    setRows((current) =>
      current.map((row) =>
        row.id === rowId
          ? { ...row, values: { ...row.values, [column]: value } }
          : row,
      ),
    )
  }

  const handleUpdateGroup = (rowId: string, group: string) => {
    const defaultSubGroup = buckets.find((bucket) => bucket.name === group)?.subBuckets[0] ?? '未分類'
    setRows((current) =>
      current.map((row) =>
        row.id === rowId ? { ...row, group, subGroup: group ? defaultSubGroup : '' } : row,
      ),
    )
  }

  const handleUpdateSubGroup = (rowId: string, subGroup: string) => {
    setRows((current) => current.map((row) => (row.id === rowId ? { ...row, subGroup } : row)))
  }

  const handleDropRow = (bucketName: string, subBucketName: string) => {
    if (!draggedRowId) return
    setRows((current) =>
      current.map((row) =>
        row.id === draggedRowId
          ? { ...row, group: bucketName, subGroup: subBucketName }
          : row,
      ),
    )
    setDraggedRowId(null)
  }

  const handleAddBucket = () => {
    const name = window.prompt('新しい大分類名を入力してください')
    if (!name?.trim()) return
    setBuckets((current) => [
      ...current,
      { id: crypto.randomUUID(), name: name.trim(), subBuckets: ['未分類'] },
    ])
  }

  const handleRenameBucket = (bucketId: string, newName: string) => {
    const oldBucket = buckets.find((bucket) => bucket.id === bucketId)
    if (!oldBucket) return

    setBuckets((current) =>
      current.map((bucket) => (bucket.id === bucketId ? { ...bucket, name: newName } : bucket)),
    )

    setRows((current) =>
      current.map((row) =>
        row.group === oldBucket.name ? { ...row, group: newName } : row,
      ),
    )
  }

  const handleRemoveBucket = (bucketId: string) => {
    const bucket = buckets.find((item) => item.id === bucketId)
    if (!bucket) return

    setBuckets((current) => current.filter((item) => item.id !== bucketId))
    setRows((current) =>
      current.map((row) =>
        row.group === bucket.name ? { ...row, group: '', subGroup: '' } : row,
      ),
    )
  }

  const handleAddSubBucket = (bucketId: string) => {
    const name = window.prompt('小箱子の名前を入力してください')
    if (!name?.trim()) return

    setBuckets((current) =>
      current.map((bucket) =>
        bucket.id === bucketId && !bucket.subBuckets.includes(name.trim())
          ? { ...bucket, subBuckets: [...bucket.subBuckets, name.trim()] }
          : bucket,
      ),
    )
  }

  const handleRenameSubBucket = (bucketId: string, oldName: string, newName: string) => {
    if (!newName.trim()) return
    const targetBucket = buckets.find((bucket) => bucket.id === bucketId)
    if (!targetBucket) return

    setBuckets((current) =>
      current.map((bucket) =>
        bucket.id === bucketId
          ? {
              ...bucket,
              subBuckets: bucket.subBuckets.map((name) => (name === oldName ? newName : name)),
            }
          : bucket,
      ),
    )

    setRows((current) =>
      current.map((row) =>
        row.group === targetBucket.name && row.subGroup === oldName
          ? { ...row, subGroup: newName }
          : row,
      ),
    )
  }

  const handleRemoveSubBucket = (bucketId: string, subBucketName: string) => {
    if (subBucketName === '未分類') return
    const targetBucket = buckets.find((bucket) => bucket.id === bucketId)
    if (!targetBucket) return

    setBuckets((current) =>
      current.map((bucket) =>
        bucket.id === bucketId
          ? { ...bucket, subBuckets: bucket.subBuckets.filter((name) => name !== subBucketName) }
          : bucket,
      ),
    )

    setRows((current) =>
      current.map((row) =>
        row.group === targetBucket.name && row.subGroup === subBucketName
          ? { ...row, subGroup: '未分類' }
          : row,
      ),
    )
  }

  return (
    <div className="app-shell">
      <header className="hero panel">
        <div>
          <h1>Risk Grouping App</h1>
          <p>
            Excel を読み込み、全列を編集しながら、ドラッグ＆ドロップで大分類・小分類へ整理できる小さな作業台です。
          </p>
        </div>
        <div className="summary-grid">
          <div className="summary-card">
            <span>総行数</span>
            <strong>{rows.length}</strong>
          </div>
          <div className="summary-card">
            <span>未分類</span>
            <strong>{rows.filter((row) => !row.group).length}</strong>
          </div>
          <div className="summary-card">
            <span>大分類数</span>
            <strong>{buckets.length}</strong>
          </div>
        </div>
      </header>

      <Toolbar
        search={search}
        onSearchChange={setSearch}
        onFileChange={handleFileChange}
        onExport={() => exportExcel(rows, columns)}
        onAddBucket={handleAddBucket}
        disabledExport={rows.length === 0}
      />

      <div className="tabs">
        <button className={viewMode === 'board' ? 'tab active' : 'tab'} onClick={() => setViewMode('board')}>
          ボード
        </button>
        <button className={viewMode === 'table' ? 'tab active' : 'tab'} onClick={() => setViewMode('table')}>
          表編集
        </button>
        <button className={viewMode === 'manage' ? 'tab active' : 'tab'} onClick={() => setViewMode('manage')}>
          分類設定
        </button>
      </div>

      {viewMode === 'board' && (
        <GroupBoard
          rows={filteredRows}
          columns={columns}
          buckets={buckets}
          draggedRowId={draggedRowId}
          onDragStart={setDraggedRowId}
          onDropRow={handleDropRow}
        />
      )}

      {viewMode === 'table' && (
        <DataTable
          rows={filteredRows}
          columns={columns}
          buckets={buckets}
          onUpdateCell={handleUpdateCell}
          onUpdateGroup={handleUpdateGroup}
          onUpdateSubGroup={handleUpdateSubGroup}
        />
      )}

      {viewMode === 'manage' && (
        <CategoryManager
          buckets={buckets}
          onRenameBucket={handleRenameBucket}
          onRemoveBucket={handleRemoveBucket}
          onAddSubBucket={handleAddSubBucket}
          onRenameSubBucket={handleRenameSubBucket}
          onRemoveSubBucket={handleRemoveSubBucket}
        />
      )}
    </div>
  )
}

export default App
