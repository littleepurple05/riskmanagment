export type RiskRow = {
  id: string
  rowNo: number
  group: string
  subGroup: string
  values: Record<string, string>
}

export type Bucket = {
  id: string
  name: string
  subBuckets: string[]
}
