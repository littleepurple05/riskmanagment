# Risk Grouping App

Excel のリスク一覧をブラウザで読み込み、ドラッグ＆ドロップで大分類・小分類へ整理できる React + Vite の小アプリです。

## できること

- `.xlsx` / `.xls` / `.csv` を読み込み
- すべての列をそのまま表示して編集
- 行をドラッグして大分類・小分類へ移動
- 大分類と小分類の追加・名称変更・削除
- 編集結果を Excel に再出力

## セットアップ

```bash
npm install
npm run dev
```

## GitHub に上げるファイル構成

```text
risk-grouping-app/
├─ package.json
├─ tsconfig.json
├─ tsconfig.app.json
├─ tsconfig.node.json
├─ vite.config.ts
├─ index.html
├─ .gitignore
├─ README.md
└─ src/
   ├─ main.tsx
   ├─ App.tsx
   ├─ styles.css
   ├─ types.ts
   ├─ utils/
   │  └─ excel.ts
   └─ components/
      ├─ Toolbar.tsx
      ├─ GroupBoard.tsx
      ├─ DataTable.tsx
      └─ CategoryManager.tsx
```

## 使い方

1. 画面上部の `Excelを読み込む` で手元のファイルを選択
2. `ボード` タブで未分類の行を右側の箱へドラッグ
3. `表編集` タブで各セルや分類名を直接編集
4. `分類設定` タブで大箱子 / 小箱子を調整
5. `Excelを書き出す` で整理後ファイルを保存

## 補足

- データはブラウザ内で処理されます
- サーバーは不要です
- 初期の大分類はご要望の 8 区分を登録済みです
